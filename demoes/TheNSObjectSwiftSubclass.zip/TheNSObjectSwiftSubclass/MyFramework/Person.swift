//
//  Person.swift
//  MyFramework
//
//  Created by 席萍萍Brook.dinglan on 2021/9/16.
//

import Foundation

public class Person: NSObject {
    
}
