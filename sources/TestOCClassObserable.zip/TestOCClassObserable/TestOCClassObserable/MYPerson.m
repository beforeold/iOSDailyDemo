#import "MYPerson.h"

@implementation MYPerson

@end
