import SwiftUI

@main
struct TestOCClassObserableApp: App {
  var body: some Scene {
    WindowGroup {
      ContentView()
    }
  }
}
